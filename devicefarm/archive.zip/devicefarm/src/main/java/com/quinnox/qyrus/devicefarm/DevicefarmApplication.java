package com.quinnox.qyrus.devicefarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevicefarmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevicefarmApplication.class, args);
	}

}
