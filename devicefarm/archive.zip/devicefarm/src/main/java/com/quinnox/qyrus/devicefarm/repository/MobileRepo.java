package com.quinnox.qyrus.devicefarm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.quinnox.qyrus.devicefarm.domain.Mobile;

@Repository
public interface MobileRepo extends JpaRepository<Mobile, Long >{

	List<Mobile> findAll();

	Mobile getOne(long parseLong);
	
	

}
