package com.quinnox.qyrus.devicefarm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quinnox.qyrus.devicefarm.domain.Mobile;
import com.quinnox.qyrus.devicefarm.repository.MobileRepo;

@Service
public class MobileServiceimpl implements MobileService {

	@Autowired
	private MobileRepo mobileRepo;
	public MobileServiceimpl() {
		
	}
	
		
	
	
	@Override
	public List<Mobile> getMobiles() {
		
		return mobileRepo.findAll();
		
	}
	
	
	@Override
	public Mobile getMobile(long device_id) {
		
		return mobileRepo.getOne(device_id);
	}
	
	@Override	
	public Mobile addMobiles(Mobile mobile) {
		
		mobileRepo.save(mobile);
		return mobile;
	}



	@Override
	public Mobile updateMobiles(Mobile mobile) {
		
		mobileRepo.save(mobile);
		return null;
	}
	
	
	@Override
	public void deleteMobile(long parseLong) {
		
		Mobile entity = mobileRepo.getOne(parseLong);
		mobileRepo.delete(entity);
	}


	

}
